<?php 
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

   include "dbconn.php";

   if (isset($_POST["ID"]))
   {
    
   $ID=$_POST["ID"];

   $query="SELECT * FROM `products` 
                  WHERE productID='$ID'";

   $cmd=mysqli_query($conn,$query);

   while($row=mysqli_fetch_assoc($cmd))
   {
      $json_arry[]=$row;
   }

   $output=json_encode(['product'=>$json_arry]);
   echo $output;
   }
?>