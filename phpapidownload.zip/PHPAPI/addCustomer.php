<?php 
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

   include "dbconn.php";

   if (isset($_POST["NAME"]))
   {
    
   $name=$_POST["NAME"];
   $address=$_POST["ADDRESS"];
   $city=$_POST["CITY"];
   $country=$_POST["COUNTRY"];
   $email=$_POST["EMAIL"];
   $pwd=$_POST["PWD"];

   $query="INSERT INTO `customers` (`customerNumber`, `customerName`, `contactLastName`, `contactFirstName`, `phone`, `addressLine1`, `addressLine2`, `city`, `state`, `postalCode`, `country`, `salesRepEmployeeNumber`, `creditLimit`, `email`, `file`, `pwd`, `type`) VALUES (NULL, '$name', NULL, NULL, NULL, '$address', NULL, '$city', NULL, NULL, '$country', NULL, NULL, '$email', NULL, '$pwd', 'M')";

    $cmd=mysqli_query($conn,$query);

    if ($cmd)
    {
      $last_id=mysqli_insert_id($conn);
      echo json_encode(["success"=>1, "id"=>$last_id, "msg"=>"user inserted"]);
    }
    else
    {
        echo json_encode(["success"=>0, "msg"=>"user not inserted"]);
    }
  
   
   }
?>