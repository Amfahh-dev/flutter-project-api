<?php 
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

  include "dbconn.php";

   if (isset($_GET['PAGE'])) 
   {
   
   $PAGE=$_GET['PAGE'];
   $PAGESIZE=4;
   $OFFSET=($PAGE-1)*$PAGESIZE;

   $query="SELECT * FROM productlines
           LIMIT $OFFSET,$PAGESIZE";
           
   $cmd=mysqli_query($conn,$query);

   while($row=mysqli_fetch_assoc($cmd))
   {
      $json_arry[]=$row;
   }

   $output=json_encode(['category'=>$json_arry]);

   echo $output;
  }

?>
