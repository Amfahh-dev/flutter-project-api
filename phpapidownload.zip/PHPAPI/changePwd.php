<?php 
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

  include "dbconn.php";

   if (isset($_POST['EMAIL'])) 
   {   
   $EMAIL=$_POST['EMAIL'];
   $PWD=$_POST['PWD'];
   $NPWD=$_POST['NPWD'];

   $query="SELECT count(*) noofrec FROM customers WHERE email='$EMAIL' and pwd='$PWD'";
           
   $cmd=mysqli_query($conn,$query);
   $row=mysqli_fetch_row($cmd);

   $noofrec=$row[0];

   if ($noofrec>0)
   {
         $query2="UPDATE customers
                    SET pwd = '$NPWD'
        WHERE email='$EMAIL' AND pwd='$PWD'";
                   
        $cmd2=mysqli_query($conn,$query2);

        echo json_encode(['success'=>1, 'msg'=>'your password has been changed']);
   }
   else
   {
          echo json_encode(['success'=>0, 'msg'=>'In valid Login/Pwd']);
   }

  }

?>
