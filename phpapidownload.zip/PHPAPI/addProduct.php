<?php 
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

   include "dbconn.php";

   if (isset($_POST["NAME"]))
   {
    
   $name=$_POST["NAME"];
   $cat=$_POST["CAT"];
   $qty=$_POST["QTY"];
   $price=$_POST["PRICE"];
   $image=$_POST["IMAGE"];
   $mimage=$_POST["MIMAGE"];
   $desc=$_POST["DESC"];

   $query="INSERT INTO `products` (`productName`, `productLine`, `productScale`, `productVendor`, `productDescription`, `quantityInStock`,
    `buyPrice`, `MSRP`, `image`, `productID`, `mimage`) VALUES ('$name', '$cat', '', '', '$desc', '$qty', 
    '$price', '', '$image', NULL, '$mimage')";

    $cmd=mysqli_query($conn,$query);

    if ($cmd)
    {
      $last_id=mysqli_insert_id($conn);
      echo json_encode(["success"=>1, "id"=>$last_id, "msg"=>"product inserted"]);
    }
    else
    {
        echo json_encode(["success"=>0, "msg"=>"product not inserted"]);
    }
  
   
   }
?>